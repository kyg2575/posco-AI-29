package com.example.defectdetection

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.net.Socket
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraActivity : AppCompatActivity() {

    private lateinit var viewFinder: PreviewView
    private lateinit var imageCapture: ImageCapture
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private lateinit var cameraExecutor: ExecutorService
    private var isRecording = false
    private var isCameraStarted = false

    private lateinit var btnCapture: Button
    private lateinit var btnRecord: Button

    companion object {
        private const val TAG = "CameraX"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.camera)

        viewFinder = findViewById(R.id.textureView)
        btnCapture = findViewById(R.id.btnCapture)
        btnRecord = findViewById(R.id.btnRecord)

        cameraExecutor = Executors.newSingleThreadExecutor()

        // 권한 요청
        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        // 사진 버튼 클릭
        btnCapture.setOnClickListener {
            if (!isCameraStarted) {
                Toast.makeText(this, "카메라가 켜지지 않았습니다.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            takePhoto()
        }

        // 녹화 버튼 클릭
        btnRecord.setOnClickListener {
            if (!isCameraStarted) {
                viewFinder.visibility = View.VISIBLE
                startCamera()
                Toast.makeText(this, "카메라를 시작합니다. 다시 버튼을 눌러주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            recordVideo()
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                Toast.makeText(this, "권한 허용됨", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "권한이 거부되었습니다.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
    private fun sendVideoToSocket(videoFile: File) {
        Thread {
            try {
                val socket = Socket("192.168.0.40", 9001) // ← 서버 IP로 바꿔줘
                val outputStream = socket.getOutputStream()
                val fileInputStream = FileInputStream(videoFile)

                val buffer = ByteArray(4096)
                var bytesRead: Int

                while (fileInputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                }

                outputStream.flush()
                outputStream.close()
                fileInputStream.close()
                socket.close()

                runOnUiThread {
                    Toast.makeText(this, "서버 전송 완료", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this, "전송 실패: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder().build()

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.HD))
                .build()

            videoCapture = VideoCapture.withOutput(recorder)

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture, videoCapture
                )
                isCameraStarted = true
            } catch (exc: Exception) {
                Log.e(TAG, "카메라 바인딩 실패", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val photoFile = File(externalMediaDirs.first(), "${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Log.e(TAG, "사진 저장 실패: ${exc.message}", exc)
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val msg = "사진 저장됨: ${photoFile.absolutePath}"
                    Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
                    Log.d(TAG, msg)
                }
            }
        )
    }

    private fun recordVideo() {
        val videoCapture = this.videoCapture ?: return

        if (!isRecording) {
            val videoFile = File(externalMediaDirs.first(), "${System.currentTimeMillis()}.mp4")
            val mediaStoreOutput = FileOutputOptions.Builder(videoFile).build()

            recording = videoCapture.output
                .prepareRecording(this, mediaStoreOutput)
                .apply { withAudioEnabled() }
                .start(ContextCompat.getMainExecutor(this)) { event ->
                    when (event) {
                        is VideoRecordEvent.Start -> {
                            btnRecord.text = "녹화 중지"
                            isRecording = true
                        }
                        is VideoRecordEvent.Finalize -> {
                            val msg = if (!event.hasError()) {
                                sendVideoToSocket(videoFile) // ✅ 서버 전송
                                "비디오 저장됨: ${videoFile.absolutePath}"
                            } else {
                                "비디오 저장 실패: ${event.error}"
                            }
                            Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
                            Log.d(TAG, msg)

                            btnRecord.text = "녹화 시작"
                            isRecording = false
                            recording = null
                        }
                    }
                }
        } else {
            recording?.stop()
            recording = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
